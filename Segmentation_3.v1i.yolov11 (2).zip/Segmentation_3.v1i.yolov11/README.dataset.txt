# Segmentation_3 > 2025-07-18 9:13am
https://universe.roboflow.com/demo-1zmmf/segmentation_3

Provided by a Roboflow user
License: CC BY 4.0

